<style>
html
{

 background-size: 120%;

background: #c9de96; /* Old browsers */
background: -moz-linear-gradient(top,  #c9de96 0%, #8ab66b 44%, #398235 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#c9de96), color-stop(44%,#8ab66b), color-stop(100%,#398235)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* IE10+ */
background: linear-gradient(to bottom,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#c9de96', endColorstr='#398235',GradientType=0 ); /* IE6-9 */
background-repeat: repeat;
background-size: cover;
 height:100%;

min-width: 100%;
}


.dropdown-menu .nav_file_option a
{
	
display:inline-block;
	margin-left:10%;
	float:right;

	margin-top: 20px;


}

.dropdown-menu .nav_file_option a img
{
	

}
body{



padding-left:20px;
padding-right:20px;
overflow: auto;

background: none;

background: #c9de96; /* Old browsers */
background: -moz-linear-gradient(top,  #c9de96 0%, #8ab66b 44%, #398235 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#c9de96), color-stop(44%,#8ab66b), color-stop(100%,#398235)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* IE10+ */
background: linear-gradient(to bottom,  #c9de96 0%,#8ab66b 44%,#398235 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#c9de96', endColorstr='#398235',GradientType=0 ); /* IE6-9 */

 	
margin:auto;

background-repeat: repeat;
background-size: cover;


}



#cic_logo
{
width:20px;
height:20px;

z-index:9999;

}

#logo_text
{
	color:#fff;
	font-size:10px;
	padding:0px;

text-shadow:0px -1px 0px gray,
0px 1px 0px #369,
-1px -1px 1px #555;


}
#main
{
	
	min-height:100%;
	padding:30px;

		
}
#weather_info
{
	
	width:97%;
	


	
}
.weather_info
{
margin-left:3%;
}

.weather_info_plus
{
	
	
	margin:auto;
	margin-top: 15px;

	
}



.title, .title td
{
font-size:12px;
background:#0B4C5F;



color:#fff;

}

tr.title td
{

}



.title_plus, .title_plus td
{
font-size:16px;
background:#0B4C5F;
color:#fff;
line-height: 33px;
text-align: center;
font-weight: bold;
}

.title_plus
{
box-shadow: 0px -1px 1px 1px #886A08;
}



.table_label
{

font-size:14px;
background:#0B4C5F;


margin-left: 3%;


color:#fff;
text-align: left;
padding:2px 7px;
margin-top:10px;
line-height: 25px;
display: inline-block;
border-radius:2px 2px 0px 0px;
font-weight: bold;


border-bottom: none;


}

.advisory_label a
{
font-size: 12px;

float:right;
margin-right:1px;

margin-bottom:-4px;
margin-top:-29px;

line-height:8px;

color:#fff;

background: #354e61; /* Old browsers */
background: -moz-linear-gradient(top,  #354e61 0%, #4a738a 50%, #42687e 51%, #729eb4 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#354e61), color-stop(50%,#4a738a), color-stop(51%,#42687e), color-stop(100%,#729eb4)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* IE10+ */
background: linear-gradient(to bottom,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#354e61', endColorstr='#729eb4',GradientType=0 ); /* IE6-9 */

box-shadow: 0px 2px 1px #123;
}




.advisory_label a:hover
{

	
	text-decoration: none;
	color:#fff;
	
}





.more_info
{
font-size:14px;
float:right;
margin-top: -13px;
margin-right: -24px;

}







div#rainfall_graph.row table
{
	
	margin:auto;
	width:97%;
	margin-top:38px;
	margin-bottom: 10px;
	
}





#rainfall_graph table tr td img
{
	width:100%;
	
border-radius:0px 0px 2px 2px;
border:1px solid #ccc;
box-shadow: 0px 8px 4px -3px #444;


}




#weather_info tr
{
line-height: 35px;

	font-family: 'PT Sans', arial, serif;

	text-align:center;
	font-size:14px;
	
	padding:10px;
	

	border-top: 0px solid #000;
	border-bottom: 5px solid rgba(0,0,0,0.2);
	
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
	
background: rgb(240,240,240); /* Old browsers */
background: -moz-linear-gradient(top,  rgba(240,240,240,1) 0%, rgba(240,240,240,1) 7%, rgba(240,240,240,1) 12%, rgba(254,254,254,1) 12%, rgba(247,247,247,1) 30%, rgba(237,237,237,1) 54%, rgba(237,237,237,1) 76%, rgba(211,211,211,1) 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(240,240,240,1)), color-stop(7%,rgba(240,240,240,1)), color-stop(12%,rgba(240,240,240,1)), color-stop(12%,rgba(254,254,254,1)), color-stop(30%,rgba(247,247,247,1)), color-stop(54%,rgba(237,237,237,1)), color-stop(76%,rgba(237,237,237,1)), color-stop(100%,rgba(211,211,211,1))); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  rgba(240,240,240,1) 0%,rgba(240,240,240,1) 7%,rgba(240,240,240,1) 12%,rgba(254,254,254,1) 12%,rgba(247,247,247,1) 30%,rgba(237,237,237,1) 54%,rgba(237,237,237,1) 76%,rgba(211,211,211,1) 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  rgba(240,240,240,1) 0%,rgba(240,240,240,1) 7%,rgba(240,240,240,1) 12%,rgba(254,254,254,1) 12%,rgba(247,247,247,1) 30%,rgba(237,237,237,1) 54%,rgba(237,237,237,1) 76%,rgba(211,211,211,1) 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  rgba(240,240,240,1) 0%,rgba(240,240,240,1) 7%,rgba(240,240,240,1) 12%,rgba(254,254,254,1) 12%,rgba(247,247,247,1) 30%,rgba(237,237,237,1) 54%,rgba(237,237,237,1) 76%,rgba(211,211,211,1) 100%); /* IE10+ */
background: linear-gradient(to bottom,  rgba(240,240,240,1) 0%,rgba(240,240,240,1) 7%,rgba(240,240,240,1) 12%,rgba(254,254,254,1) 12%,rgba(247,247,247,1) 30%,rgba(237,237,237,1) 54%,rgba(237,237,237,1) 76%,rgba(211,211,211,1) 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f0f0f0', endColorstr='#d3d3d3',GradientType=0 ); /* IE6-9 */


	margin: 40px;
	
	text-decoration: none;




}


#file_option img
{
	width:10px;
	display:block;

	
}

#weather_file_option img
{

margin-bottom: 5px;
margin-top: 5px;
margin-right: 5px;

	
}


#weather_info tr td
{


text-align: center;
padding-left:5px;



}

td.number
{
	background:#006699;
	color:#fff;
	font-weight: bold;

}


#weather_info, thead th,tbody tr
{
	font-size: 12px;
}
#weather_info tr:hover
{


background:rgba(250,250,250,1);

}


#weather_info_cloud_icon img {
  width:40px;
  
  margin-top: 5px;
  margin-bottom: -15px;
}

#weather_info tr:hover> td#weather_info_cloud_icon img {
   width:40px;
}


#weather_info_date
{
	color:#0B3861;

	text-shadow:0px -1px 0px #369;

}





#weather_forecast_text.row table
{
	
	width:100%;
background:rgba(255,255,255,0.3);


}
#weather_forecast_text_header tr{
	width:100%;
}
#weather_forecast_text_header td
{
	color:#eee;
	height:35px;
	font-weight: bold;

box-shadow:0px 2px 1px black,
	0px -1px 1px white;

font-size: 16px;

	background:#0B4C5F;








}


#weather_forecast_text_info td{
height:100px;
color:#369;
background: #fff;
line-height:2em;
text-align: justify;
padding:5px;
font-size:20px;
border-radius:0px 0px 2px 2px;
border:1px solid #ccc;
box-shadow: 0px 8px 4px -3px #444;

}

#weather_info td#remark
{
	text-align: left;
}

#icons_area
{
	margin-top:33px;

	
}
.main_icon a
{
background: #354e61; /* Old browsers */
background: -moz-linear-gradient(top,  #354e61 0%, #4a738a 50%, #42687e 51%, #729eb4 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#354e61), color-stop(50%,#4a738a), color-stop(51%,#42687e), color-stop(100%,#729eb4)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* IE10+ */
background: linear-gradient(to bottom,  #354e61 0%,#4a738a 50%,#42687e 51%,#729eb4 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#354e61', endColorstr='#729eb4',GradientType=0 ); /* IE6-9 */

	margin:5px 0px;
	width:90%;
	padding:5px;
	text-align: center;
	color:cyan;
	box-shadow:0px 2px 2px -1px #000;
	
}


.icon a
{
	text-decoration: none;
	color:#0489B1;

}

nav.cl-effect-21.main_icon a
{
	height: 90px;
	font-size:20px;
	width:90%;
box-shadow: 0px 3px 3px -1px #444;
background: #fff;

color:#123;

}

nav.cl-effect-21.main_icon a img
{
	
	height:60px;

	margin:auto;
	display:block;
	margin-top: -10px;
}



.icon
{


color:#fff;
margin:2px 10px ;
text-align:center;

background:#0B4C5F;

min-width: 170px;
box-shadow:0px 1px 2px #fff,
0px -1px 1px white;

}


.cl-effect-10
{
	width:90%;
}

.icon td a
{
	color:white;
	text-decoration: none;
	font-weight: bold;
}


.icon td img
{
	width:60px;
	padding: 5px;
}


.footer
{
	background:gray;
	position: absolute;
    left: 0px;
    bottom: 0px;
    height: 30px;
    width: 100%;
}



.widget_notice
{ 

background:rgba(0,0,0,0.2);
border:2px solid #eee;

border-radius: 5px;
width:350px;
padding:10px;
margin:auto;
text-align:center;
margin-top:50px;
color:#fff;
text-shadow:0px 1px 1px #000;



}

a#add_now
{

display:block;
width:100px;
margin:auto;
margin-top:20px;

	border-radius:3px;


	background: #c7e89d; /* Old browsers */
	background: -moz-linear-gradient(top,  #c7e89d 1%, #7dcc78 45%, #41a048 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(1%,#c7e89d), color-stop(45%,#7dcc78), color-stop(100%,#41a048)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top,  #c7e89d 1%,#7dcc78 45%,#41a048 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top,  #c7e89d 1%,#7dcc78 45%,#41a048 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top,  #c7e89d 1%,#7dcc78 45%,#41a048 100%); /* IE10+ */
	background: linear-gradient(to bottom,  #c7e89d 1%,#7dcc78 45%,#41a048 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#c7e89d', endColorstr='#41a048',GradientType=0 ); /* IE6-9 */




	color:#040;
	font-weight: bold;
	text-shadow:0px 1px 1px green;

}












#forecast_panel
{
	
	
	
}


tr.current_day td
{


background: #b2e1ff; /* Old browsers */
background: -moz-linear-gradient(top,  #b2e1ff 0%, #66b6fc 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#b2e1ff), color-stop(100%,#66b6fc)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #b2e1ff 0%,#66b6fc 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #b2e1ff 0%,#66b6fc 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #b2e1ff 0%,#66b6fc 100%); /* IE10+ */
background: linear-gradient(to bottom,  #b2e1ff 0%,#66b6fc 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b2e1ff', endColorstr='#66b6fc',GradientType=0 ); /* IE6-9 */




}


#weather_records
{
width:96%;
margin: auto;
margin-top:50px;


}

div.dataTables_length
{
margin-top:-60px;
margin-bottom: -4px;


}
div.dataTables_length label, div.dataTables_filter label,div.dataTables_length label select
{
font-size: 16px;
color:#222;

}

table.data-table tr td
{
	
	min-width:140px;

}


div.dataTables_filter label, div.srch
{

margin-top: -20px;
}

div.dataTables_info
{
color:#fff;
margin-left: -75px;
font-size: 12px;
text-shadow:0px 1px 1px #000;

position:absolute;


}

div.dataTables_paginate
{
float:right;
}

#weather_records thead th.sorting
{
	background:#333;
	line-height: 30px;
	color:#eee;
	font-size: 14px;
	
}
th.sorting_asc, th.sorting_desc, th.sorting_both
{
	background-color:#123	;
	color:#fff;
	font-weight: bold;
		font-size: 5px;
}



table.data-table tr th
{
	
	border:1px solid #fff;
min-width: 160px;
text-align: center;
line-height:40px;


}


.data_table_file_option
{

float:right;

}




#download_area
{
margin-top: 30px;
margin-bottom: -30px;
margin-right: 350px;


}

a#download
{

	width:150px;
	padding:5px;
	text-align: center;
	float:right;
	text-decoration: none;
	border-radius: 5px 5px 0px 0px;
	color:#222;
	border:1px solid #ddd;
	border-bottom: none;
	font-size: 20px;
	margin-right:2px;
line-height: 25px;
background: #fff;	
}


a#download:hover
{

color:#111;	
background: #eee;	
}

a.excel:after
{

float:right;

margin:5px;
margin-top:2px;
    
  
}

a.csv:after
{

float:right;

margin:5px;
margin-top:2px;
    
  
}

a.print:after
{

float:right;

margin:5px;
margin-top:2px;
  
}

.sm li a
{

	
}

.navbar-nav li a.nav_icon
{

padding:7px 20px;


}

.dropdown-menu li a
{
text-align: left;
}

li.movie_list a
{
	width: 180px;
	text-align: left;
}

li.nav_title a
{
	font-size: 20px;
	font-weight: 1000;
	color:red;
	text-align: center;
}

div.navbar.navbar-default.navbar-fixed-top
{
	min-height: 60px;
	
}


</style>